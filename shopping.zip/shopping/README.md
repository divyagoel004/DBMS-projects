# online-shopping-webvsite-in-php

Shopping Cart System is the Simple shopping Solution. It’s a full-featured website and shopping cart system that bends over backwards to give you the flexibility you need to runyour online store.

The basic concept of the application is to allow the customer to shop virtually using the Internet and allow customers to buy the items and articles of their desire from the store.

The information pertaining to the products are stores on an RDBMS at the server side (store). The Server process the customers and the items are shipped to the address submitted by them. The details of the items are brought forward from the database for the customer view based on the selection through the menu and the database of all the products are updated at the end of each transaction.

What is Shopping Cart system ?
Online shopping is a form of electronic shopping store where the buyer is directly online to the seller’s computer usually via the internet. There is no intermediary service. The sale and purchase transaction is
completed electronically and interactively in real- time.

The development of this new system contains the following activities, which try to develop on- line
application by keeping the entire process in the view of database integration approach. User gets its eamil id and password to access their account.

Administrator of Shopping Cart System has multiple features such as Add, Delete, Update shopping Items.

Features of shopping cart
Secure registration and profile managementfacilities for Customers.
Browsing through the e-Mall to see the itemsthat are there in each category of products likeApparel, Kitchen accessories,
Bath accessories, Food items etc.
Creating a Shopping cart so that customer canShop N number of items and checkout finally withthe entire shopping cart
Customers should be able to mail the Shopabout the items they would like to see in theShop
Secured mechanism for checking out from theShop( Credit card verification mechanism).Updates to customers about the Recent Items inthe Shop.
Uploading Most Purchased Items in eachcategory of products in the Shop like Apparel,Kitchen accessories, Bath accessories,
Food items etc.
Brief overview of the technology
 

HTML: HTML is used to create and save webdocument. E.g. Notepad/Notepad++
CSS : (Cascading Style Sheets) Create attractiveLayout
JavaScript: it is a programming language,commonly use with web browsers.
Back end: PHP, MySQL

PHP: Hypertext Preprocessor (PHP) is atechnology that allows software developers tocreate
dynamically generated web pages, in HTML, XML,or other document types, as per client request.
PHP is open source software.

MySQL: MySql is a database, widely used foraccessing querying, updating, and managing datain databases.
Software Requirement(any one)
WAMP Server
XAMPP Server
MAMP Server
LAMP Server
Installation Steps
Download zip file and Unzip file on your local server.
Put this file inside “c:/wamp/www/” .
Database Configuration:
Open phpmyadmin
Create Database named “shop”.
Import database shop.sql.
Open Your browser put inside URL:
“http://localhost/store/”
To Login as admin put inside URL:”http://localhost/store”
user login details:
Login Id: yugeshverma@gmail.com
Password:123456


visit- https://projkectworlds.in